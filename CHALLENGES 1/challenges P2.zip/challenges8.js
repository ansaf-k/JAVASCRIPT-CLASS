bills = [ 22, 295, 176, 440, 37, 105, 10, 1100, 86, 52]

const calcTip = (bill) => {
    return (bill <= 300 && bill >=50) ? (bill * 0.15) : (bill * 0.20);
}

for (let i=0; i<bills.length; i++){
    console.log(`total = ${bills[i]+(calcTip(bills[i]))}`);
}