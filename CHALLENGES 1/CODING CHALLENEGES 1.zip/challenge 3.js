scoreDolphins = ((96 + 108 + 89)/3);
scoreKoalas = ((88 + 91 + 110) / 3);
console.log(`${scoreDolphins.toFixed(2)}`);
console.log(scoreKoalas.toFixed(2));

if (scoreDolphins > scoreKoalas){
    console.log("Dolphins win the trophy");
}
else if (scoreDolphins == scoreKoalas){
    console.log("Both win the trophy" );
}
else {
    console.log("Koalas win the trophy");
}